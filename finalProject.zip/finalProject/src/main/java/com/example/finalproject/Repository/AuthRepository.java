package com.example.finalproject.Repository;

import com.example.finalproject.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuthRepository extends JpaRepository<User, Integer> {

    User findUserById (Integer id);

     List<User> findUserByRole(String role);

     User findUserByUsername (String username);

}
