package com.example.finalproject.Service;

import com.example.finalproject.Api.ApiException;
import com.example.finalproject.Model.Orders;
import com.example.finalproject.Model.Student;
import com.example.finalproject.Model.UsedItem;
import com.example.finalproject.Model.User;
import com.example.finalproject.Repository.AuthRepository;
import com.example.finalproject.Repository.OrdersRepository;
import com.example.finalproject.Repository.StudentRepository;
import com.example.finalproject.Repository.UsedItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UsedItemService {

    private final UsedItemRepository usedItemRepository;
    private final AuthRepository userRepository;
    private final OrdersRepository ordersRepository;
    private final StudentRepository studentRepository;

    public List<UsedItem> getAllUsedItem() {
        return usedItemRepository.findAll();
    }

    public void addUsedItem(UsedItem usedItem) {
        usedItemRepository.save(usedItem);
    }

    public void updateUsedItem(Integer id, UsedItem usedItem) {
        UsedItem usedItem1=usedItemRepository.findUsedItemById(id);
        if(usedItem1==null) {
            throw new ApiException("Used item Not Found");
        }
        usedItem1.setName(usedItem.getName());
        usedItem1.setDescription(usedItem.getDescription());
        usedItem1.setPrice(usedItem.getPrice());
        usedItem1.setCategory(usedItem.getCategory());
        usedItem1.setUsed(usedItem.isUsed());
        usedItemRepository.save(usedItem1);
    }

    public void deleteUsedItem(Integer id) {
        UsedItem usedItem1=usedItemRepository.findUsedItemById(id);
        if(usedItem1==null) {
            throw new ApiException("Used item Not Found");
        }
        usedItemRepository.delete(usedItem1);
    }

    // Buy method by Omar
    public void buyUsedItem(Integer itemId, Integer buyerId) {
        // Find the used item
        UsedItem usedItem = usedItemRepository.findById(itemId)
                .orElseThrow(() -> new ApiException("Used item not found"));

        // Check if the item already has a buyer (i.e., it's already sold)
        if (usedItem.getBuyer() != null) {
            throw new ApiException("Item is already sold");
        }

        // Find the buyer
        User buyer = userRepository.findById(buyerId)
                .orElseThrow(() -> new ApiException("Buyer not found"));

        // Check if the seller exists
        if (usedItem.getSeller() == null) {
            throw new ApiException("Seller not assigned for this item");
        }

        // Create a new order
        Orders order = new Orders();
        order.setOrderDate(LocalDate.now());
        order.setTotalPrice(usedItem.getPrice());
        order.setStatus("COMPLETED");
        order.setBuyer(buyer);
        order.setSeller(usedItem.getSeller());

        ordersRepository.save(order);

        // Set the buyer and link the order
        usedItem.setBuyer(buyer);
        usedItem.setOrders(order);

        usedItemRepository.save(usedItem);
    }

    //Omar
    // Get items by seller method by Omar
    public List<UsedItem> getItemsBySeller(Integer sellerId) {
        User seller = userRepository.findUserById(sellerId);
        if (seller == null) {
            throw new ApiException("Seller not found");
        }
        return usedItemRepository.findAllBySeller(seller);
    }

}
